// swiftc Hello.swift -o hello
// ./hello

print("Hello World")
