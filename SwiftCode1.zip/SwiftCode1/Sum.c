
//In C Language
//Write Sum Function Which Takes 2 int and Return int
	//Return 	-> Valid Sum
	//Otherwise -> Print Not Able To Calculate Sum

int sum( int x, int y ) {
	int z = x + y
	return z;
}

//BAD CODE
int sum( int x, int y ) {
	if ( MIN <= x, y <= MAX ) { // Always True
		int z = x + y;
		return z;
	} else {
		printf("Not Able To Calculate Sum");
	}
}

//BAD CODE
int sum( int x, int y ) {
	int z = x + y;
	if (  MIN <= z <= MAX ) { // Always True
		return z;
	} else {
		printf("Not Able To Calculate Sum");
	}
}

//BAD CODE
int sum( int x, int y ) {
	if (  MIN <= x + y <= MAX ) { // Always True
		return z = x + y;
	} else {
		printf("Not Able To Calculate Sum");
	}
}

//BAD CODE
//Violates Type Idea
int sum( int x, int y ) {
	long int xx = (long) x;
	long int yy = (long) y;
	
	long int z = x + y;
	if (  INT_MIN <= z <= INT_MAX ) { // Always 
		return (int) z;
	} else {
		printf("Not Able To Calculate Sum");
	}
}

//BAD CODE - Time Complexity Wise
int sum( String x[], String y[] ) {
	//	Digit To Digit Add
}

//Right Direction!
int sum( int x, int y ) {
	check = INT_MAX - x - y
	if check > 0 {
		return x + y;
	} else {
		printf("Not Able To Calculate Sum");
	}
}



