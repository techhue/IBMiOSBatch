
#include <stdio.h>
#include <limits.h>

int sum( int x, int y ) {
	int result = 0;

	//Not confirming to int type
	if ( y > 0 && x > INT_MAX - y ) ||
	   ( y < 0 && x < INT_MIN - y ) {
	   	printf("Cann't Calcualate Sum These Values");
	   	//return result;
	}  else {
		//Confirms To int Type
		return result = x + y;
	}

	return result;
}

int main() {

}