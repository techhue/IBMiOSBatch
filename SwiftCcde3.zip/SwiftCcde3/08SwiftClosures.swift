
func stepForward5(input: Int)  -> Int { return input + 5 }
func stepBackward5(input: Int) -> Int { return input - 5 }
func chooseStepFunction5(backwards: Bool) -> (Int) -> Int {
    return backwards ? stepBackward5 : stepForward5
}

//class chooseStepFunctionInteresting
func chooseStepFunctionInteresting(backwards: Bool) -> (Int) -> Int {
	func stepForward(input: Int)  -> Int {  return input + 1 }
	func stepBackward(input: Int) -> Int {  return input - 1 }
    return backwards ? stepBackward : stepForward
}


//Algorithm Invariant
func marchTowardsZero(value: Int, choose: (Bool) -> (Int) -> Int ) {
	var currentValue = value
	let moveNearerToZero = choose(currentValue > 0)
	//chooseStepFunction(backwards: currentValue > 0)

	print("Counting To Zero:")
	while currentValue != 0 {
	    print("\(currentValue)... ")
	    currentValue = moveNearerToZero(currentValue)
	}
	print("Zero Reached!")
}
marchTowardsZero(value: 10, choose: chooseStepFunction5)
marchTowardsZero(value: 10, choose: chooseStepFunctionInteresting)


var names = ["Ding", "Dong", "Ting", "King", "Tong", "Kong", "Ping"]
func backwards(firstString: String, secondString: String) -> Bool {
	return firstString > secondString
}
func forwards(firstString: String, secondString: String) -> Bool {
	return firstString < secondString
}

print(names)
var backward = names.sorted(by: backwards)
print("Decending Order: ", backward)

var forward = names.sorted(by: forwards)
print("Acending Order : ",forward)


func sum(x: Int, y: Int) -> Int { return x + y }
func sub(x: Int, y: Int) -> Int { return x - y }
func mul(x: Int, y: Int) -> Int { return x * y }

func calculator(x: Int, y: Int, operation: (Int, Int) -> Int ) -> Int { 
	return operation(x, y)
}

let a = 20
let b = 30
var result = calculator(x: a, y: b, operation: sum)
print(result)

result = calculator(x: a, y: b, operation: sub)
print(result)

let something: (Int, Int, (Int, Int)-> Int) -> Int = calculator
result = something(a, b, mul)
print(result)

// Closure/Lamdbas
let sum1 = { (x: Int, y: Int) -> Int  in  return x + y  }
let sub1 = { (x: Int, y: Int) -> Int  in  return x - y  }
let mul1 = { (x: Int, y: Int) -> Int  in  return x * y  }

result = calculator(x: a, y: b, operation: sum1)
print(result)

result = calculator(x: a, y: b, operation: sub1)
print(result)

result = something(a, b, mul1)
print(result)


// Closures/Lambdas
let backwards1 = { (first: String, second: String) -> Bool in return first > second }
let forwards1  = { (first: String, second: String) -> Bool in return first < second }

print(names)
backward = names.sorted(by: backwards1)
print("Decending Order: ", backward)

forward = names.sorted(by: forwards1)
print("Acending Order : ",forward)

forward = names.sorted(by: { (first: String, second: String) -> Bool in 
	return first < second 
} )
print("Acending Order : ",forward)

forward = names.sorted(by: { (first, second) -> Bool in 
	return first < second 
} )
print("Acending Order : ",forward)

forward = names.sorted(by: { (first, second) in first < second } )
print("Acending Order : ",forward)

forward = names.sorted(by: { $0 < $1 } )
print("Acending Order : ",forward)

forward = names.sorted(by:  <  )
print("Acending Order : ",forward)

forward = names.sorted { $0 < $1 }  // Trailing Lamdba
print("Acending Order : ",forward)

forward = names.sorted { (first, second) in first < second }
print("Acending Order : ",forward)


//Polymorphism -> Meachanism Default Arguments
func createName(firstName: String, middleName: String = "", lastName: String = "") -> String {
	return firstName+middleName+lastName
}

print(createName(firstName: "Ram"))
print(createName(firstName: "Ram", lastName: "Singh"))
print(createName(firstName: "Ram", middleName: "Kapoor", lastName: "Singh"))
print(createName(firstName: "Ram", middleName: "Kapoor"))

