

// TYPE IS A THEROEM
enum CompassPoint {
	case North
	case South
	case East
	case West
}

// PROGRAM IS IS PROOF!
// Type Safely
var direction: CompassPoint = CompassPoint.North
direction = .East
switch direction {
	case .North:
		print("Travel To North")
	case .South:
		print("Travel To South")
	case .East:
		print("Travel To East")
	case .West:
		print("Travel To West")
	// default:
	// 	print("Travel To Unknown Direction")
}

print(direction)

enum Planet: Int {
    case Mercury=10, Venus, Earth, Mars, Jupiter, Saturn, Uranus, Neptune, Others
}

let somePlanet = Planet.Earth
switch somePlanet {
	case .Earth:
	    print("Mostly Harmless")
	default:
	    print("Not a safe place for humans")
}


print(somePlanet)
print(Planet.Earth.rawValue)

