
// https://repl.it/languages/swift
// swiftc Hello.swift -o hello
// ./hello

print("Hello World")

//Immutable Values
//Type Inferencing: Inference Type as Int
let maximumNumberOfLoginAttempt = 10

//Mutable Values
//Type Inferencing: Inference Type as Int
var currentLoginAttempt = 0

print(maximumNumberOfLoginAttempt)
print(currentLoginAttempt)

// maximumNumberOfLoginAttempt = 100
currentLoginAttempt = 100
print(currentLoginAttempt)

//var welcomeMessage: String = "Welcome IBMers!"
var welcomeMessage: String 
welcomeMessage = "Welcome IBMers!"
print(welcomeMessage)

let friendlyMessage: String
friendlyMessage = "4 Pegs!"
print(friendlyMessage)

//Type Inferencing: Inference Type as String
let languageName = "Swift"
print(languageName)

// Compile Time Error
// let a: Int8 = 127 + 1 //= 128

let a: Int8 = 127
// let aa: Int8 = a
// let aaa: Int8 = aa
let b: Int8 = -128

// Run Time Error
// let c: Int8 = a + 1

print(a)
print(b)

let minValue = Int8.min
let maxValue = Int8.max 

print("Int8 Type")
print("\tMinimum Value:", minValue)
print("\tMaximum Value:", maxValue)

print("UInt8 Type")
print("\tMinimum Value:", UInt8.min)
print("\tMaximum Value:", UInt8.max)

print("Int16 Type")
print("\tMinimum Value:", Int16.min)
print("\tMaximum Value:", Int16.max)

print("UInt16 Type")
print("\tMinimum Value:", UInt16.min)
print("\tMaximum Value:", UInt16.max)

print("Int32 Type")
print("\tMinimum Value:", Int32.min)
print("\tMaximum Value:", Int32.max)

print("UInt32 Type")
print("\tMinimum Value:", UInt32.min)
print("\tMaximum Value:", UInt32.max)

print("Int64 Type")
print("\tMinimum Value:", Int64.min)
print("\tMaximum Value:", Int64.max)

print("UInt64 Type")
print("\tMinimum Value:", UInt64.min)
print("\tMaximum Value:", UInt64.max)

print("Int Type")
print("\tMinimum Value:", Int.min)
print("\tMaximum Value:", Int.max)

print("UInt Type")
print("\tMinimum Value:", UInt.min)
print("\tMaximum Value:", UInt.max)


// let three: Int = 3
// let pointValue: Double = 0.14159

//Type Inferencing: From Right Handside Value
//Type Binding: Binded To Variable

// 	Type Inferencing -> 3 is Type of Int
// 	Type Binding 	 -> threeValue is Binded with Int
let threeValue: Int8 = 3 		// Type of 3 is Int
let pointValue: Float = 0.14159 // Type of Dounle

//Compile Time Error
//let piValue = threeValue + pointValue

let piValue = Float(threeValue) + pointValue
print(piValue)

let pi = 3.14159

//Type Inferencing and Binding will Happen After Calculation of Value
//Constant Folding
let anotherPi = 3 + 0.14159

print(pi)
print(anotherPi)

let decimalInteger = 17
let binaryInteger = 0b10001
let octalInteger = 0o21
let hexadecimalInteger = 0x11

print(decimalInteger)
print(binaryInteger)
print(octalInteger)
print(hexadecimalInteger)

//_____________________________________________

let decimalDouble = 12.1875
let exponentDouble = 1.21875e1

print(decimalDouble)
print(exponentDouble)

let oneMillion = 1_000_000
let justOverOneMillion = 1_000_000.000_000_1
let paddedDouble = 000123.456

print(paddedDouble)
print(oneMillion)
print(justOverOneMillion)


let twoThousand: UInt16 = 2_000
let one: UInt8 = 1
let twoThousandOne = twoThousand + UInt16(one)
// let twoThousandOne = UInt8(twoThousand) + one
print(twoThousandOne)

print(piValue)
print( Int(piValue) )
print( Int( -3.987 ) )

typealias AudioSample = UInt16
var amplitudeValue = AudioSample.min
print(amplitudeValue)


// let orangesAreOrange: Bool = true 
// let turnipsAreDelicious: Bool = false 
let orangesAreOrange = true 
let turnipsAreDelicious  = false 

//if (turnipsAreDelicious) {
if turnipsAreDelicious {
	print("Tasty Turnips!")
} else {
	print("Horrible Turnips")
}

let i = -10
//if ( i ) {
//if ( Bool(i) ) {

if ( i == -10 ) {
	print("Balleee Balleeee")
} else {
	print("Oyeee Hoyeeee")
}

if true {
	print("Balleee Balleeeeee!!!")
}
//} else {
// 	print("Dead Code...")
// }


// Type Inference: Right Side is Tuple of (Int, String)
//let http404Error: (Int, Int) = (404, "Not Found")

var http404Error: (Int, String) = (404, "Not Found")
print(http404Error)

let (statusCode, statusMessage) = http404Error 	//Unpacking 
print("The Status Code: \(statusCode)") 		//String Extrapolation/Substitution
print("The Status Message: \(statusMessage)")	//String Extrapolation/Substitution

let someTuple: (Int, Int) = (10, 20)
//http404Error = someTuple
print(someTuple)

print("The Status Code: \(http404Error.0)") 		//String Extrapolation/Substitution
print("The Status Message: \(http404Error.1)") 		//String Extrapolation/Substitution

let (justTheStatusCode, _ ) = http404Error 	//Unpacking 
//let (justTheStatusCode, ding, dong ) = http404Error 	//Unpacking 
// let (justTheStatusCode) = http404Error 	//Unpacking 
print("The Status Code: \(justTheStatusCode)") 		//String Extrapolation/Substitution

//print("The Status Code: \(http404Error.xx)") 		//String Extrapolation/Substitution

//Named Tuple
// let http200Status: (statusCode: Int, description: String) = (statusCode: 200, description: "OK")
let http200Status = (statusCode: 200, description: "OK")
print("The Status Code: \(http200Status.0)") 		//String Extrapolation/Substitution
print("The Status Message: \(http200Status.1)")	//String Extrapolation/Substitution

print("The Status Code: \(http200Status.statusCode)") 		//String Extrapolation/Substitution
print("The Status Message: \(http200Status.description)")	//String Extrapolation/Substitution

let someTuple1 = (10, 20, 30, 40, 50, 60, 70, 80)
print(someTuple1)

let someTuple2: ((Int, Int), (String, String)) = ((10, 20), ("Ding", "Dong"))
print(someTuple2)

var someTuple3 = (10, 20)
let someTuple4 = (100, 200)
//var someTuple5 = someTuple3 + someTuple4
print(someTuple3)

someTuple3.0 = 1000
someTuple3.1 = 2000
print(someTuple3)


