#include <stdio.h>

typedef struct human_type {
	int id;
	float salary;
} Human;

void playWithValues() {
	int a = 20;
	float f = a;
	float ff = 20.90;
	int aa = ff;
	printf(" %d %f %f %d", a, f, ff, aa);
}

void playWithPointers() {
	int a = 20;
	int * iptr = &a;
	char * cptr = iptr;
	float * fptr = cptr;
	double * dptr = fptr;
	Human * hptr = dptr;
	void *vptr = hptr;
	printf(" %d", * (float *) vptr);
	printf(" %d", * (double *) vptr);
	printf(" %d", * (int *) vptr);
}

int main() {
	playWithValues();
	playWithPointers();
}

