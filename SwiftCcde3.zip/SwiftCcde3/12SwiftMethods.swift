
class Counter {
    var count = 0
    func increment() {
        count = count + 1
    }
    func incrementBy(amount: Int) {
        count += amount
    }
    func reset() {
        count = 0
    }
}

let counter = Counter()
counter.increment()
counter.incrementBy(amount: 5)
counter.reset()

class CounterTwo {
    var count: Int = 0
    func incrementBy(amount: Int, numberOfTimes: Int) {
        count += amount * numberOfTimes
    }
}

let counter2 = CounterTwo()
counter2.incrementBy(amount: 5, numberOfTimes:3)



struct Point {
    var x = 0.0, y = 0.0
    func isToTheRightOfX(x: Double) -> Bool {
        return self.x > x
    }
}

let somePoint = Point(x: 4.0, y: 5.0)

if somePoint.isToTheRightOfX(x: 1.0) {
    print("This point is to the right of the line where x == 1.0")
}


struct Point2 {
    var x = 0.0, y = 0.0
    mutating func moveByX(deltaX: Double, deltaY:Double) {
        x += deltaX
        y += deltaY
    }
}
var somePoint2 = Point2(x: 1.0, y: 1.0)
somePoint2.moveByX(deltaX: 2.0, deltaY:3.0)
print("The point is now at (\(somePoint2.x), \(somePoint2.y))")


enum TriStateSwitch {
    case Off, Low, High
    mutating func next() {
        switch self {
            case .Off:
                self = .Low
            case .Low:
                self = .High
            case .High:
                self = .Off
        }
    }
}
var ovenLight = TriStateSwitch.Low
ovenLight.next()
ovenLight.next()



