
struct TimesTable {
    let multiplier: Int

    subscript(index: Int) -> Int {
        return multiplier * index
    }
}

let threeTimesTable = TimesTable(multiplier: 3)
let value = threeTimesTable[6] // Subscript Operator
		//  threeTimesTable.subscript(index: 6)

print("six times three is \(value)")

