
// Variable someString is Type of String
var someString: String = "Hello!"
print("SomeString Value: ", someString)
// someString = nil

// Variable someString1 is Type of Optional(String)
var someString1: String? = "Hello!"
//print("SomeString Value: ", someString1)

// Optional Unwrapping - But Got Disappointment
// print("SomeString Value: ", someString1!) 

// Always Check Optional Values for Non Nil
// Then Only Unwrap

if someString1 != nil {
	print("SomeString Unwrapped Value : ", someString1!) 
} else {
	print("Found Nothing!")
}

someString1 = nil
//print("SomeString Value: ", someString1)

if someString1 != nil {
	print("SomeString Unwrapped Value : ", someString1!) 
} else {
	print("Found Nothing!")
}


var someNumber: Int = 900
print("Something Value: ", someNumber)
// someNumber = nil

var someNumber1: Int? = 900
//print("Something Value: ", someNumber1)
// someNumber1 = nil
if someNumber1 != nil {
	print("Something Unwrapped Value: ", someNumber1!)
} else {
	print("Found Nothing!")
}

var someDouble: Double = 900.90
print("Something Value: ", someDouble)
// someDouble = nil

var someDouble1: Double? = 900.90
//print("Something Value: ", someDouble1)
// someDouble1 = nil

if someDouble1 != nil {
	print("Something Unwrapped Value: ", someDouble1!)
} else {
	print("Found Nothing!")	
}

someDouble1 = nil
//print(someDouble1)
//print("SomeString Value: ", someDouble1!) 
if someDouble1 != nil {
	print("Something Unwrapped Value: ", someDouble1!)
} else {
	print("Found Nothing!")	
}

print("Type Conversion Experiment...")
let possibleNumber = "12389"
//let possibleNumber: String = "123ABC"
//let convertedNumber = Int(possibleNumber)
//let convertedNumber: Int? = Int(possibleNumber) != nil ? convertedNumber! : print("Found Nothing")

//Written By Programmer
let convertedNumber: Int? = Int(possibleNumber)
if convertedNumber != nil {
	print("Converted Number: ", convertedNumber! )	
} else {
	print("Found Nothing!")	
}

//Idioms Style: //Written By Programmer
	// Convert possibleNumber
	// It will check for Nullability
	// If Not Null Then Convert To NonNullable
	// Use That Stuff

if let actualNumber = Int(possibleNumber) {
    print("\(possibleNumber) has an integer value of \(actualNumber)")
} else {
    print("\(possibleNumber) could not be converted to an integer")
}

//Compiler Will Generate For Above Idiom
let convertedOptional: Int? = Int(possibleNumber)
if convertedOptional != nil {
	let actualNumber: Int = convertedOptional!
    print("\(possibleNumber) has an integer value of \(actualNumber)")
} else {
    print("\(possibleNumber) could not be converted to an integer")
}

//Idioms Style: //Written By Programmer
if let firstNumber = Int("4"), let secondNumber = Int("42"), 
	firstNumber < secondNumber {
    print("\(firstNumber) < \(secondNumber)")
} else {
	print("Something Else...")
}

//Compiler Will Generate For Above Idiom
let firstNumberOptional = Int("4") 
let secondNumberOptional = Int("42")
if firstNumberOptional != nil && secondNumberOptional != nil {
	let firstNumber 	= firstNumberOptional!  
	let secondNumber 	= secondNumberOptional!

	if firstNumber < secondNumber {
		print("\(firstNumber) < \(secondNumber)")		
	}
} else {
	print("Something Else...")
}

if var actualNumber = Int(possibleNumber) {
	actualNumber = actualNumber + 1
    print("\(possibleNumber) has an integer value of \(actualNumber)")
} else {
    print("\(possibleNumber) could not be converted to an integer")
    // print(actualNumber)
}
// print(actualNumber)

//Programmer Written Code
let a: Int? = nil
let b: Int? = 10
let c: Int? = 8
if let aa = a, let bb = b, let cc = c {
	print("Sum Is:", aa + bb + cc)
} else {
	print("Life is Messy!")
}

//Write Equivalent Code: Compiler Will Generate...

// let a: Int? = 4
// let b: Int? = nil
// let c: Int? = 8
if a != nil && b != nil && c != nil {
	let aa = a!
	let bb = b!
	let cc = c!
	print("Sum Is:", aa + bb + cc)
} else {
	print("Life is Messy!")
}

// Common Code
let defaultPrimeMinister = "Modi"
let motherDefinedPrimeMinister : String? = "Manmohan Singh" // defaults to nil

// Idiomatic Code: Programmer Written Code
if let nationPrimeMinister = motherDefinedPrimeMinister {
    print("\(nationPrimeMinister)")
} else {
	let nationPrimeMinister = defaultPrimeMinister
    print("\(nationPrimeMinister)")
}

//____________________________________________________________________
//Nil-Coalescing Operator OR Default Value Operator
//____________________________________________________________________

// Elegant Idiomatic Code
let nationPrimeMinister = motherDefinedPrimeMinister ?? defaultPrimeMinister
print(nationPrimeMinister)

// Compiler Generate Code
let nationPrimeMinisterGenerated: String 
if motherDefinedPrimeMinister != nil {
	nationPrimeMinisterGenerated = motherDefinedPrimeMinister!
} else {
	nationPrimeMinisterGenerated = defaultPrimeMinister
}
print(nationPrimeMinisterGenerated)

var xx: Int? = 100
let defaultValue = 0
let yy = xx ?? defaultValue
print(yy)

// For Following Code
	// let yy = xx ?? defaultValue
// Equivalent Code
	// let yy = xx != nil ? xx! : defaultValue

// The nil-coalescing operator (a ?? b) unwraps an optional a if it contains a value, or returns a default value b if a is nil. The expression a is always of an optional type. The expression b must match the type that is stored inside a.

// The nil-coalescing operator is shorthand for the code below:

// a != nil ? a! : b

