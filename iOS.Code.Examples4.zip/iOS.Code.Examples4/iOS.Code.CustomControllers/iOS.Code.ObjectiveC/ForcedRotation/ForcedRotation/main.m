//
//  main.m
//  ForcedRotation
//
//  Created by Tom Parry on 15/11/12.
//  Copyright (c) 2012 b2cloud. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char *argv[])
{
	@autoreleasepool {
	    return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
	}
}
