//
//  ViewController.swift
//  CustomShapeViews
//
//  Created by Nagarajan on 8/30/14.
//  Copyright (c) 2014 Nagarajan. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    convenience init() {
        self.init(nibName: nil, bundle: nil)
    }
    
    override init(nibName nibNameOrNil: String!, bundle nibBundleOrNil: Bundle!) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
                            
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        drawTraingleView()
        drawCircleView()
        drawOctagonView()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func drawTraingleView()
    {
        let traingleView: TraingleView = TraingleView(frame: CGRect(x: 20, y: 20, width: 100, height: 100))
        self.view.addSubview(traingleView)
    }
    
    func drawCircleView()
    {
        let circleView: CircleView = CircleView(frame: CGRect(x: 130, y: 20, width: 100, height: 100))
        self.view.addSubview(circleView)
    }
    
    func drawOctagonView()
    {
        let octagonView: OctagonView = OctagonView(frame: CGRect(x: 20, y: 130, width: 100, height: 100))
        self.view.addSubview(octagonView)
    }

}

