//
//  OctagonView.swift
//  CustomShapeViews
//
//  Created by Nagarajan on 8/30/14.
//  Copyright (c) 2014 Nagarajan. All rights reserved.
//

import UIKit

class OctagonView: UIView {
    
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    /*
    // Only override drawRect: if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func drawRect(rect: CGRect)
    {
        // Drawing code
    }
    */
    
    override class var layerClass : AnyClass
    {
        return CAShapeLayer.self
    }
    
    func shapeLayer() -> CAShapeLayer
    {
        return self.layer as! CAShapeLayer
    }
    
    override func layoutSubviews() {
        let layer: CAShapeLayer = shapeLayer()
        let octagonPath: CGMutablePath = CGMutablePath()
        CGPathMoveToPoint(octagonPath, nil, self.bounds.size.width/4, self.bounds.origin.y)
        CGPathAddLineToPoint(octagonPath, nil, (self.bounds.size.width/4)*3, self.bounds.origin.y);
        CGPathAddLineToPoint(octagonPath, nil, self.bounds.size.width, self.bounds.size.height/4);
        CGPathAddLineToPoint(octagonPath, nil, self.bounds.size.width, 3*(self.bounds.size.height/4));
        CGPathAddLineToPoint(octagonPath, nil, 3*(self.bounds.size.width/4), self.bounds.size.height);
        CGPathAddLineToPoint(octagonPath, nil, 3 * (self.bounds.size.width/4), self.bounds.size.height);
        CGPathAddLineToPoint(octagonPath, nil, self.bounds.size.width/4, self.bounds.size.height);
        CGPathAddLineToPoint(octagonPath, nil, self.bounds.origin.x, 3 * (self.bounds.size.height / 4));
        CGPathAddLineToPoint(octagonPath, nil, self.bounds.origin.x, self.bounds.size.height / 4);
        octagonPath.closeSubpath();
        layer.path = octagonPath;
        layer.strokeColor = UIColor.green.cgColor
        layer.fillColor = UIColor.red.cgColor
        layer.opacity = 0.6
    }

}
