Circle Detection
================

A UIGestureRecognizer for iOS to detect circular gestures with one finger.

Check out this blog entry for more info
[Creating custom gesture recognisers for iOS](http://blog.federicomestrone.com/2012/01/31/creating-custom-gesture-recognisers-for-ios/ "Blog entry on blog.federicomestrone.com")
