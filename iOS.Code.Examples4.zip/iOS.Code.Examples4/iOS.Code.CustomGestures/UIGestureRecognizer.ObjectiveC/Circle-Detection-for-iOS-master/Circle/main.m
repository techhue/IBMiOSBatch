//
//  main.m
//  Circle
//
//  Created by Federico Mestrone on 27/04/2013.
//  Copyright (c) 2013 Moodsdesign Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, nil);
    }
}
