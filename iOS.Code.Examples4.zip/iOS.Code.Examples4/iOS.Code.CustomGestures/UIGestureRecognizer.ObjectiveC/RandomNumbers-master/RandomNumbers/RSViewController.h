//
//  RSViewController.h
//  RandomNumbers
//
//  Created by Ravi Shankar on 29/04/14.
//  Copyright (c) 2014 Ravi Shankar. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RSViewController : UIViewController

@property (nonatomic,strong) IBOutlet UILabel *displayRandomNumber;

@end
