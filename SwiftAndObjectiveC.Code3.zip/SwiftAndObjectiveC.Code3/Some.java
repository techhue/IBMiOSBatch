
package learnJava;

public class Some {
	public static void playWithIf() {
		int expr = -10;
		boolean b = true; //boolean(expr);

		if ( true ) {
			System.out.print("\n Ding Dong");
		} else {
			System.out.print("\n Ping Pong");
		}
	}

	public static void playWithStrings() {
		String name1 = "World!";
		String name2 = "World!";

		if ( name1 == name2 ) {
			System.out.print("\nEqual Strings : " + name1 + name2);
		} else {
			System.out.print("\nUnEqual Strings : " + name1 + name2);
		}
		
		String someName = new String("World!");

		if ( name1 == someName ) {
			System.out.print("\nEqual Strings : " + name1 + someName);
		} else {
			System.out.print("\nUnEqual Strings : " + name1 + someName);
		}
	}

	public static void playWithArrays() {
		// ArrayList<Integer> someNumbers = new ArrayList<Integer>( 10, 20, 30, 40, 50, 60) ;
		// ArrayList <Integer> someNumbersCopy = someNumbers;
		
		int [] someNumbers = { 10, 20, 30, 40, 50, 60 };
		int [] someNumbersCopy = someNumbers;

		// System.out.print( String(someNumbers) );
		// System.out.print( someNumbersCopy );
		
		System.out.println();
		for (int number: someNumbers ) {
			System.out.print(number + " ");
		}
		System.out.println();
		for (int number: someNumbersCopy ) {
			System.out.print(number + " ");
		}
		someNumbersCopy[0] = 100;

		// System.out.print( someNumbers );
		// System.out.print( someNumbersCopy ) ;	
		System.out.println();
		for (int number: someNumbers ) {
			System.out.print(number + " ");
		}
		System.out.println();
		for (int number: someNumbersCopy ) {
			System.out.print(number + " ");
		}
	}
	
	public static void playWithNull() {
		String name = "Hello!";
		System.out.print(name);
		
		name = null;
	}

	public static void main(String args[]) {
		// playWithChar();
		// playWithIf();

		// playWithStrings();
		playWithArrays();

		// playWithNull();

	}
}
