

// Initialization is the process of preparing an instance of a class, structure, or enumeration for use. This process involves setting an initial value for each stored property on that instance and performing any other setup or initialization that is required before the new instance is ready for use.

// Classes and structures must set all of their stored properties to an appropriate initial value by the time an instance of that class or structure is created. 
// Stored properties cannot be left in an indeterminate state.

// You can set an initial value for a stored property within an initializer, or by assigning a default property value as part of the property’s definition.

// NOTE: When you assign a default value to a stored property, or set its initial value within an initializer, the value of that property is set directly, without calling any property observers.

// Initializers are called to create a new instance of a particular type. In its simplest form, an initializer is like an instance method with no parameters, written using the init keyword:


// init() {
//     // perform some initialization here
// }

struct Fahrenheit {
    var temperature: Double
    init() {
    	print("Default Init Called")
        temperature = 32.0
    }
}

var f = Fahrenheit()
print("The default temperature is \(f.temperature)° Fahrenheit")

// Message To Method Mapping Uses
	// 	No. Of Arguments
	//  Type Of Arguments
	//  Label of The Arguments

struct Celsius {
    var temperatureInCelsius: Double = 0.0

    init(fromFahrenheit fahrenheit: Double) {
        temperatureInCelsius = (fahrenheit - 32) / 1.8
    }

    init(fromKelvin kelvin: Double) {
        temperatureInCelsius = kelvin - 273.15
    }

    // init(fromKelvin ding: Double) {
    //     temperatureInCelsius = ding - 273.15
    // }

    //Use This In Rarest of Rare Cases
    init(_ celsius: Double) {
        temperatureInCelsius = celsius
    }
}

let boilingPointOfWater = Celsius(fromFahrenheit: 212.0)
print(boilingPointOfWater)

let freezingPointOfWater = Celsius(fromKelvin: 273.15)
print(freezingPointOfWater)

let bodyTemperature = Celsius(37.0)
print(bodyTemperature)

struct Color {
    let red, green, blue: Double

    init(red: Double, green: Double, blue: Double) {
    	print("Constructor with 3 Arguments")
        self.red   = red
        self.green = green
        self.blue  = blue
    }

    init(white: Double) {
    	print("Constructor with 1 Arguments")
        red     = white
        green   = white
        blue    = white
    }
}

let magenta = Color(red: 1.0, green: 0.0, blue: 1.0)
print(magenta)

let halfGray = Color(white: 0.5)
print(halfGray)


class SurveyQuestion {
    var text: String
    var response: String?

    init(text: String) {
        self.text = text
    }

    func ask() {
        print(text)
    }
}

let cheeseQuestion = SurveyQuestion(text: "Do you like cheese?")
cheeseQuestion.ask()

if let response = cheeseQuestion.response {
	print(response)
} else {
	print("Nothiness Found...")
}

cheeseQuestion.response = "Yes, I do like cheese."
if let response = cheeseQuestion.response {
	print(response)
} else {
	print("Nothiness Found...")
}

// Compiler Will Generate Memberwise Initilser
	// init(name: nil, quantity: 1, purchased: false)

struct ShoppingListItem {
    var name: String?
    var quantity = 1
    var purchased = false
}

var item = ShoppingListItem()
print(item)

item = ShoppingListItem(name: "Bagpiper", quantity: 2, purchased: true)
print(item)



//_________________________________________________________________________

struct Size  {  var width = 0.0, height = 0.0 }
struct Point {	var x = 0.0, y = 0.0 }

struct Rect {
    var origin = Point()
    var size = Size()

  	init() { } 
  	// Compiler Is GENERATING!
  	// init() { 
  	// 	self.init(origin: Point(), size: Size())   
  	// }

    // Compiler Is GENERATING!
    // You Can Go Against The Generation Idea!
    init(origin: Point, size: Size) {
        self.origin = origin
        self.size = size
    }

    init(center: Point, size: Size) {
        let originX = center.x - (size.width / 2)
        let originY = center.y - (size.height / 2)
        self.init(origin: Point(x: originX, y: originY), size: size)
    }
}

let basicRect = Rect() // Rect(origin: Point(), size: Size())
print(basicRect)

let originRect = Rect(origin: Point(x: 2.0, y: 2.0), size: Size(width: 5.0, height: 5.0))
print(originRect)

let centerRect = Rect(center: Point(x: 4.0, y: 4.0), size: Size(width: 3.0, height: 3.0))
print(centerRect)



class Vehicle {
    var numberOfWheels = 0
    var description: String {
    	return "Something"
        // return "\(numberOfWheels) wheel(s)"
    }

    init() {  
    	print("Constructor: Vehicle")

    	print("Constructor: Vehicle - Completed")
    }
}

// let vehicle = Vehicle()
// print("Vehicle: \(vehicle.description)")

class Bicycle: Vehicle {
    override init() {
    	print("Constructor: Bicycle")
        super.init()
        numberOfWheels = 2
        print("Constructor: Bicycle - Completed")
    }
}

let bicycle = Bicycle()
print("Bicycle: \(bicycle.description)")

//______________________________________________________________________________
print("\n")

class Food {
    var name: String
    init(name: String) {
        self.name = name
    }

    convenience init() {
        self.init(name: "[Unnamed]")
    }
}

let namedMeat = Food(name: "Bacon")
let mysteryMeat = Food()

class RecipeIngredient: Food {
    var quantity: Int

    init(name: String, quantity: Int) {
        self.quantity = quantity
        super.init(name: name)
    }

    override convenience init(name: String) {
        self.init(name: name, quantity: 1)
    }
}

let oneMysteryItem = RecipeIngredient()
let oneBacon = RecipeIngredient(name: "Bacon")
let sixEggs = RecipeIngredient(name: "Eggs", quantity: 6)


class Human {
	var firstName: String = ""
	var middleName: String = ""
	var lastName: String = ""

	// Designated Initialiser - Make Memberwise Initialiser
	init(firstName: String, middleName: String, lastName: String) {
		self.firstName 	= firstName
		self.middleName = middleName
		self.lastName 	= lastName
	}

	// Don't Prefer This Style
	// init(firstName: String, lastName: String) {
	// 	self.firstName 	= firstName
	// 	self.lastName 	= lastName
	// }

	// Rather Prefer This Style
	convenience init(firstName: String, lastName: String) {
		self.init(firstName: firstName, middleName: "", lastName: lastName)
	}

	convenience init(firstName: String) {
		// self.init(firstName: firstName, lastName: "")
		self.init(firstName: firstName, middleName: "", lastName: "")
	}

	func name() -> String {
		return firstName + middleName + lastName
	}
}

let salman1 = Human(firstName: "Salman", middleName: "Salim", lastName: "Khan")
print( salman1.name() )

let salman2 = Human(firstName: "Salman", lastName: "Khan")
print( salman2.name() )

let salman3 = Human(firstName: "Salman")
print( salman3.name() )


struct Animal1 {
    let species: String
    
    init(species: String) {
        self.species = species
    }
}

let someCreature: Animal1 = Animal1(species: "Giraffe")
// print(someCreature)

struct Animal2 {
    let species: String
    
    init?(species: String) {
        if species.isEmpty { return nil }
        self.species = species
    }
}

let someCreature1: Animal2? = Animal2(species: "Giraffe")
// print(someCreature1)




class Animal {
    let species: String
    
    init(species: String) {
    	print("Initaliser Called")
        self.species = species
    }
    
    deinit {
    	print("Deninitaliser Called")
    }
}

var someAnimal: Animal? = Animal(species: "Gabbar!")
print(someAnimal)
someAnimal = nil








