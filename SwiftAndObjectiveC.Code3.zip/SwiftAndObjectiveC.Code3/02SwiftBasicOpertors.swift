
var aa = 5
var bb = 10

//aa = bb 
print(aa)

let (x, y) = (1, 2) //Unpacking
print(x, y)

print(aa + bb)
print(aa - bb)
print(aa * bb)
print(aa / bb)


// a % b
// a = ( b x some multiplier ) + remainder

print( 9 % 4 )
print( -9 % 4 )
print( 9 % -4 )
print( -9 % -4 )

// print( 9 % 2.5 )

// aa++
// ++aa

aa = aa + 1
aa += 1
print(aa)

let threeValue = 3
let minusThree = -threeValue
let plusThree = -minusThree
print(minusThree)
print(plusThree)

print( 1 == 1 )
print( 2 == 1 )
print( 2 != 1 )
print( 2 > 1 )
print( 2 >= 1 )
print( 1 >= 1 )

let contentHeight = 50
let hasHeader = false
//let rowHeight = contentHeight + ( (hasHeader) ? 50 : 20 ) 
var choiceValue = ( hasHeader ? 50 : (contentHeight == 40) ? 10 : 100  ) 
print("Choice Value Using Ternary Operator: ", choiceValue)

if hasHeader {
	choiceValue = 50
} else if ( contentHeight == 40 ) {
	choiceValue = 10
} else {
	choiceValue = 100
}
print("Choice Value Using if-else Construct: ", choiceValue)

if hasHeader {
	choiceValue = 50
} else {
	choiceValue = (contentHeight == 40) ? 10 : 100 
}
print("Choice Value Using if-else+Ternary: ", choiceValue)

let rowHeight = contentHeight + choiceValue
print(rowHeight)

let names = [ "Ding", "Dong", "King", "Kong", "Ting", "Tong" ]
let namesCount = names.count
print(names)

print()
for i in 0..<namesCount {
	print("Person at \(i) is: \(names[i])")
}

for name in names {
	print("Person Name: \(name)")
}

print()
for name in names[2...] {
	print("Person Name: \(name)")	
}

print()
for name in names[...2] {
	print("Person Name: \(name)")	
}

print()
for name in names[..<2] {
	print("Person Name: \(name)")	
}

print()
for name in names[2...5] {
	print("Person Name: \(name)")	
}

let range1 = 1...10
print(range1)
for value in range1 {
	print(value)
}

let range2 = ...10
print(range2)
// for value in range2 {
// 	print(value)
// }

let range3 = 1...
print(range3)
// for value in range3 {
// 	print(value)
//}

for value in range3 {
	if value == 100 { break }
	print(value)
}

let start 	= 10
let end 	= 100
let range4 = start...end
print(range4)
for value in range4 {
	print(value, terminator:"   ")
}


let namesTuple = ( "Ding", "Dong", "King", "Kong", "Ting", "Tong" )
for name in namesTuple {
	print("Person Name: \(name)")	
}


print("Table of 5!")

//Close Interval: [1, 10]
for index in 1...10 {
	print(index, index * 5)
}

//Half Open/Close Interval: [1, 10)
for index in 1..<10 {
	print(index, index * 5)
}

let allowedEntry = false 
if !allowedEntry {
	print("ACCESS DENIED!")
}

let enteredDoorCode = true 
let passedRetinaScan = false 

if enteredDoorCode && passedRetinaScan {
	print("Welcome! Access Granted!")
} else {
	print("ACCESS DENIED!")
}

let hasDoorKey = false
let knowsPassword = true
if hasDoorKey || knowsPassword {
	print("Welcome! Access Granted!")
} else {
	print("ACCESS DENIED!")
}

if enteredDoorCode && passedRetinaScan || hasDoorKey || knowsPassword {
	print("Welcome! Access Granted!")	
} else {
	print("ACCESS DENIED!")
}

if (enteredDoorCode && passedRetinaScan) || hasDoorKey || knowsPassword {
	print("Welcome! Access Granted!")	
} else {
	print("ACCESS DENIED!")
}


let name = "World!"
let someName = "World!"

if name == someName {
	print("Hello \(name)")
} else {
	print("I don't know about \(name)")
}

let fruits0 = (0, "Mangos")
let fruits1 = (1, "Apple")
let fruits2 = (2, "Guava")
let fruits3 = (3, "Banana")
let fruits4 = (3, "Banana")

print( fruits1 <= fruits2 )
print( fruits3 == fruits4 )

print(name + someName)

let dog: Character = "🐶"
let cow: Character = "🐮"
let cowdog = "🐶" + "🐮"

print(dog)
print(cow)
print(cowdog)


let initialBits: UInt8 = 0b00001111
let invertedBits = ~initialBits

// Bitwise AND
let firstSixBits: UInt8 = 0b11111100
let lastSixBits:  UInt8 = 0b00111111
let middleFourBits = firstSixBits & lastSixBits


// Bitwise OR
let someBits: UInt8 = 0b10110010
let moreBits: UInt8 = 0b01011110
let combinedBits = someBits | moreBits

// Bitwise XOR
let firstBits: UInt8 = 0b00010100
let otherBits: UInt8 = 0b00000101
let outputBits = firstBits ^ otherBits

// Bitwise Left and Right Shift
let shiftBits: UInt8 = 4
shiftBits << 1
shiftBits << 2
shiftBits << 5
shiftBits << 6
shiftBits >> 2




