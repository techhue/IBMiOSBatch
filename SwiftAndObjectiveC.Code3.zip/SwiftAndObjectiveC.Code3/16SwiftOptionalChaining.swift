
class Person {
    var residence: Residence?
}

class Residence {
    var numberOfRooms = 1
    var address: Address?
}

class Address {
	var street: String = "Swaraga Lok!"
	var colony: String = ""
	var cty: String = ""
	var country: String = ""
}

let john = Person()
john.residence = Residence()
john.residence?.address = Address()

if let roomCount = john.residence?.numberOfRooms {
    print("John's residence has \(roomCount) room(s).")
} else {
    print("Unable to retreive the number of rooms.")
}

if let street = john.residence?.address?.street {
    print("Jack's street name is \(street).")
} else {
    print("Unable to retrieve the address.")
}

