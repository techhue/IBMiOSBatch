
// Structures, Enums, Arrays, Tuples, String, Int, Bool, Float, Double Are Value Types
 
// Getter and Setters Functions 
	// For Each Property

// Default Value Initialisers
	// defaultInitialiser() {
	// 	width 	= 0
	// 	height 	= 0
	// 	ding = 0
	// }

// Default Memberwise Constructor
	// Resolution(width: Int, height: Int)
 
 struct Resolution {
 	var width 	= 0
 	var height 	= 0
 	let ding  = 0 	
 // 	var ding: Int = 10 {
 // 		get {
 // 			return 10 + ding
 // 		}
 // 		// set(value) {
 // 		// 	self = value
 // 		// }
 // 	}
 }

var resolution = Resolution()
//var resolution = Resolution(width: 0, height: 0)

print(resolution)

// let vga = Resolution(width: 640, height: 480)
//var vga = Resolution(width: 640, height: 480)

var vga = Resolution(width: 640, height: 480)
print( vga.width )
print( vga.height )

print(vga)

print("Ding Value: ", vga.ding)
// Ding Value:  10
//vga.ding = 1111
//print("Ding Value: ", vga.ding)

vga.height = 800
// vga.ding = 90

print(vga)


// Value Type
var hd = Resolution(width: 1920, height: 1080)
print("HD Resolution:", hd)
var cinema = hd
print("Cinema Resolution:", cinema)
cinema.height = 2000
print("HD Resolution:", hd)
print("Cinema Resolution:", cinema)


var someArray: [Int] = [10, 20, 30, 40, 50]
print(someArray)
var someArrayCopy = someArray
print(someArrayCopy)
someArray[0] = 100
print(someArray)
print(someArrayCopy)


// Classes Are Also Reference Types
 class VideoMode {
 	var resolution = Resolution()
 	var frameRate = 0.0
 	var name: String = ""
 }

let tenEighty = VideoMode()
tenEighty.resolution = hd
tenEighty.frameRate = 60
tenEighty.name = "1080"

print(tenEighty.resolution, tenEighty.frameRate, tenEighty.name )

// Reference Assignment
let tenEightyCopy = tenEighty

print(tenEightyCopy.resolution, tenEightyCopy.frameRate, tenEightyCopy.name )
tenEightyCopy.frameRate = 120
print(tenEightyCopy.resolution, tenEightyCopy.frameRate, tenEightyCopy.name )
print(tenEighty.resolution, tenEighty.frameRate, tenEighty.name )

if tenEighty === tenEightyCopy {
	print("Both Refers To Same Objects...")
} else {
	print("Both Refers To Different Objects...")
}

// if vga === cinema {
// 	print("Both Refers To Same Objects...")
// } else {
// 	print("Both Refers To Different Objects...")
// }

// Closure Is Reference Type
var something = { () -> String in return "Hello" }
var something1 = something

print(something())
print(something1())

// if something === something1 {
// 	print("Both Refers To Same Objects...")
// } else {
// 	print("Both Refers To Different Objects...")
// }


var tuple = (10, 20)
var tuple1 = tuple
tuple1.0 = 100
print(tuple)
print(tuple1)

