
struct Vector2D {
	var x = 0.0, y = 0.0
}

// Operator Overloading
func + (left: Vector2D, right: Vector2D) -> Vector2D {
	return Vector2D(x: left.x + right.x, y: left.y + right.y)
}

func == (left: Vector2D, right: Vector2D) -> Bool {
	return left.x == right.x && left.y == right.y
}

let vector1 = Vector2D(x: 4.0, y: 8.0)
print(vector1)

let vector2 = Vector2D(x: 2.0, y: 1.0)
print(vector2)

let vector3 = vector1 + vector2
print(vector3)

let vector4 = Vector2D(x: 2.0, y: 1.0)
print(vector4)

if vector1 == vector4 {
	print("Vectors Are Equal!")
} else {
	print("Vectors Are UnEqual!")
}

if vector2 == vector4 {
	print("Vectors Are Equal!")
} else {
	print("Vectors Are UnEqual!")
}
