
class MediaItem {
    var name: String
    init(name: String) {
        self.name = name
    }
}

class Movie: MediaItem {
    var director: String
    init(name: String, director: String) {
        self.director = director
        super.init(name: name)
    }
}

class Song: MediaItem {
    var artist: String
    init(name: String, artist: String) {
        self.artist = artist
        super.init(name: name)
    }
}

let library: [MediaItem] = [
    Movie(name: "Casablanca", director: "Michael Curtiz"),
    Song(name: "Blue Suede Shoes", artist: "Elvis Presley"),
    Movie(name: "Citizen Kane", director: "Orson Welles"),
    Song(name: "The One And Only", artist: "Chesney Hawkes"),
    Song(name: "Never Gonna Give You Up", artist: "Rick Astley")
]

// print(library)

func countMedia(library: [MediaItem]) -> (movie: Int, song: Int) {
    var movieCount = 0
    var songCount  = 0
    for item in library { // item variable Type is MediaItem
        if item is Movie {
            movieCount += 1
            print("Counted Movie: \(item.name)")
        } else if item is Song {
            songCount  += 1
            print("Counted Song : \(item.name)")
        }
    }

    return (movie: movieCount, song: songCount)
}

var mediaCount = countMedia(library: library)
print("Movie Count:", mediaCount.movie)
print("Song Count :", mediaCount.song)


let someObjects: [AnyObject] = [
    Movie(name: "2001: A Space Odyssey", director: "Stanley Kubrick"),
    Movie(name: "Moon", director:"Duncan Jones"),
    Song(name: "Blue Suede Shoes", artist: "Elvis Presley"),
    Movie(name: "Alien", director: "Ridley Scott"),
    Song(name: "The One And Only", artist: "Chesney Hawkes"),
    Song(name: "Never Gonna Give You Up", artist: "Rick Astley"),
    MediaItem(name: "Ding Dong"),
    MediaItem(name: "Useless Media"),
]

func countMedia(library: [AnyObject]) -> (movie: Int, song: Int) {
    var movieCount = 0
    var songCount  = 0
    for item in library {
        if item is Movie { // item variable Type is AnyObject
            movieCount += 1
            let movie = item as! Movie
            print("Counted Movie: \(movie.name) - \(movie.director)")
        } else if item is Song {
            songCount  += 1
            let song = item as! Song
            print("Counted Song: \(song.name) - \(song.artist)")
        } else if item is MediaItem {
            let media = item as! MediaItem
            print("Counted Song: \(media.name)")
        }
    }

    return (movie: movieCount, song: songCount)
}

mediaCount = countMedia(library: someObjects)
print("Movie Count:", mediaCount.movie)
print("Song Count :", mediaCount.song)

var things = [Any]()
things.append(0)
things.append(0.0)
things.append(42)
things.append(3.1459)
things.append("hello")
things.append((3.0, 5.0))
things.append(Movie(name: "Ghostbusters", director: "Ivan Reitman"))

print(things)

for thing in things {
    switch thing {
        case 0 as Int:
            print("zero as an Int")
        case 0 as Double:
            print("zero as a Double")
        case let someInt as Int:
            print("an integer value of \(someInt)")
        case let someDouble as Double where someDouble > 0:
            print("a positive double value of \(someDouble)")
        case is Double:
            print("some other double value that I don't want to print")
        case let someString as String:
            print("a string value of \"\(someString)\"")
        case let (x, y) as (Double, Double):
            print("an (x, y) point at \(x), \(y)")
        case let movie as Movie:
            print("a movie called '\(movie.name)', dir. \(movie.director)")
        default:
            print("something else")
        }
}


