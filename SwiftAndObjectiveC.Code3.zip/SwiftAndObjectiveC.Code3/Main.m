/*
clang -framework Foundation Hello.m -o output
./output
*/

#include <stdio.h>

#import <Foundation/Foundation.h>

// XYZPerson.h
// XYZPerson Type/Class Declaration
@interface XYZPerson : NSObject
	@property(nonatomic, assign) NSString * firstName;
	@property(nonatomic, assign) NSString * lastName;

     - (void) sayHello;  // Instance Method Declaration
     - (void) saySomething:(NSString *)greeting;
@end

// XYZPerson.m
// #import "XYZPerson.h"
// XYZPerson Type/Class Implementation
@implementation XYZPerson
// - (id) init {

// }
- (void)sayHello { // Instance Method Implementation
    	// NSLog(@"Hello, World To XYZPerson!");
    	[self saySomething: @"Balleee Balleee...!!!"];
    	//self.saySomething("Balleeee Ballee...!!!") In Swift Langauge
	    
	    self.firstName = [ [NSString alloc] initWithString: @"Ding"];
		self.lastName = [ [NSString alloc] initWithString: @"Dong"];
}
- (void)saySomething:(NSString *)greeting {
       NSLog(@"%@", greeting);
}
@end

// Inheritance
@interface XYZShoutingPerson : XYZPerson

@end

@implementation XYZShoutingPerson
- (void)saySomething:(NSString *)greeting {
    NSString *uppercaseGreeting = [greeting uppercaseString];
    NSLog(@"%@", uppercaseGreeting);
}
@end


// Categories Over Class
// #import "XYZPerson.h"
@interface XYZPerson (XYZPersonNameDisplayAdditions)
- (NSString *) lastNameFirstNameString;
@end

@implementation XYZPerson (XYZPersonNameDisplayAdditions)
- (NSString *)lastNameFirstNameString {
    return [NSString stringWithFormat:@"%@, %@", self.lastName, self.firstName];
}
@end

// Exenstions Over Class
// @interface XYZPerson ()
// - (NSString *) dancing;
// @end

// @implementation XYZPerson ()
// - (NSString *) dancing {
//     return [NSString stringWithFormat:@"%@, %@", @"Dance ", @"Baby Dance!"];
// }
// @end

int main(int argc, char **argv) {
	printf("\nHello World!\n");

	XYZPerson *xyzObject = [ [XYZPerson alloc] init ];
	[xyzObject sayHello];
	[xyzObject saySomething: @"Life is Beautiful!!!"];

	XYZShoutingPerson *xyzShouting = [ [XYZShoutingPerson alloc] init ];
	[xyzShouting saySomething: @"Hey Keep Quite!!!"];

	NSString *result = [xyzObject lastNameFirstNameString];
	NSLog(@"%@", result);

	// NSString *result = [xyzObject dancing];
	// NSLog(@"%@", result);
}

