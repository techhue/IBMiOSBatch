
class IntStack {
    var items = [Int]()
    
    func push(item: Int) {
        items.append(item)
    }
    
    func pop() -> Int {
        return items.removeLast()
    }
}

var intstack = IntStack()
intstack.push(item: 10)
intstack.push(item: 20)
intstack.push(item: 30)
print(intstack.pop())
print(intstack.pop())

class StringStack {
    var items = [String]()
    
    func push(item: String) {
        items.append(item)
    }
    
    func pop() -> String {
        return items.removeLast()
    }
}

var stringstack = StringStack()
stringstack.push(item: "Ding")
stringstack.push(item: "Dong")
stringstack.push(item: "King")
print(stringstack.pop())
print(stringstack.pop())

// Generic Stack
class Stack<T> {
    var items = [T]()
    
    func push(item: T) {
        items.append(item)
    }
    
    func pop() -> T {
        return items.removeLast()
    }
}

var stringstack1 = Stack<String>()
stringstack1.push(item: "Ding")
stringstack1.push(item: "Dong")
stringstack1.push(item: "King")
print(stringstack1.pop())
print(stringstack1.pop())

var intstack1 = Stack<Int>()
intstack1.push(item: 10)
intstack1.push(item: 20)
intstack1.push(item: 30)
print(intstack1.pop())
print(intstack1.pop())

var stackGen = Stack<Double>()
stackGen.push(item: 10)
stackGen.push(item: 20)
stackGen.push(item: 30)
print(stackGen.pop())
print(stackGen.pop())


