
#import <Foundation/Foundation.h>

@interface XYZPerson : NSObject
     - (void) sayHello;
@end

