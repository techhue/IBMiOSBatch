
protocol Superpower {
	func fly()
	func saveWorld()
}

protocol Capability {
	func dancing()
	func singing()
}

class Spiderman: Superpower {
	func fly() { print("Fly Like Spiderman!") }
	func saveWorld() { print("SaveWorld Like Spiderman!") }
}

let spider = Spiderman()
spider.fly()
spider.saveWorld()

class Superman: Superpower, Capability {
	func fly() { print("Fly Like Superman!") }
	func saveWorld() { print("SaveWorld Like Superman!") }
	func dancing() { print("Dance Like Superman!") }
	func singing() { print("Sing  Like Superman!") }
}

let superman = Superman()
superman.fly()
superman.saveWorld()
superman.dancing()
superman.singing()

class Heman: Superpower {
	func fly() { print("Fly Like Heman!") }
	func saveWorld() { print("SaveWorld Like Heman!") }
}

class Hanuman: Superpower {
	func fly() { print("Fly Like Hanuman Ji!") }
	func saveWorld() { print("SaveWorld Like Hanuman Ji!") }	
}

class Human1: Heman {
	override func fly() 	  { super.fly()  }
	override func saveWorld() { super.saveWorld() }
}

// Composition
class Human {
	var power: Superpower?
	func fly() 	     { power?.fly()  }
	func saveWorld() { power?.saveWorld() }
}

let human = Human()
human.power = Spiderman()
human.fly()
human.saveWorld()

human.power = Superman()
human.fly()
human.saveWorld()

human.power = Heman()
human.fly()
human.saveWorld()

human.power = Hanuman()
human.fly()
human.saveWorld()

