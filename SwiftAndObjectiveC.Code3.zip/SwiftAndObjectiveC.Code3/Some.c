
#include <stdio.h>

void playWithChar() {
		// signed char ch = 'A';
	unsigned char ch = 'A';
	for ( ; ch < 255 ; ch++ ) {
		printf(" %c", ch);
	}
}
/*
A. 190
B. 191
C. Infinite
D. All The Above
E. None of These
*/

void playWithIf() {
	int expr = -10;
	if (expr) {
		printf("\n Ding Dong");
	} else {
		printf("\n Ping Pong");
	}
}

void playWithNull() {
	char * someString = "Hello!";
	printf("%s", someString);
	someString = NULL;

	int someNumber = 900;
	printf("%d", someNumber);
	someNumber = (int) NULL;
}

void playWithArrays() {
	int someNumbers[] = { 10, 20, 30, 40, 50, 60 };
	int * someNumbersCopy = someNumbers;
	
	printf("\n");
	for (int i = 0 ; i < 6 ; i++ ) {
		printf(" %d ", someNumbers[i]);
	}
	
	printf("\n");
	for (int i = 0 ; i < 6 ; i++ ) {
		printf(" %d ", someNumbersCopy[i]);
	}

	someNumbersCopy[0] = 100;

	printf("\n");
	for (int i = 0 ; i < 6 ; i++ ) {
		printf(" %d ", someNumbers[i]);
	}
	
	printf("\n");
	for (int i = 0 ; i < 6 ; i++ ) {
		printf(" %d ", someNumbersCopy[i]);
	}
}
	

int main() {
	// playWithChar();
	// playWithIf();
	// playWithNull();
	playWithArrays();
}

