
class Vehicle {
    var numberOfWheels: Int
    var maxPassengers: Int
    func description() -> String {
        return "\(numberOfWheels) wheels up to \(maxPassengers) passengers"
    }
    init() {
    	print("Vehicle : Getting Constructted")
        numberOfWheels = 0
        maxPassengers = 1
    }

    func ride() {
    	print("Ride Vehicle")
    }
}

let someVehicle = Vehicle()
// print( someVehicle.description() )
someVehicle.ride()

print()

class Bicycle: Vehicle {
    var bell: Bool //= true

    override init() {
 		print("Bicycle : Getting Constructted")
        super.init() // Call Default Constructure From Parent Class
        bell = true
        numberOfWheels = 2
        // super.init()
    }

	override func ride() {
    	print("Ride Bicycle")
    }
}

let bicycle = Bicycle()  // Bycycle(Object.init())
// print("Bicycle: \(bicycle.description())")
bicycle.ride()

class Tandem: Bicycle {
    override init() {
        super.init()
        maxPassengers = 2
    }
}
let tandem = Tandem()
print("Tandem: \(tandem.description())")
tandem.ride()
