/*
clang -framework Foundation Hello.m -o output
./output
*/

#include <stdio.h>

int main(int argc, char **argv) {
	printf("\nHello World!\n");
}

