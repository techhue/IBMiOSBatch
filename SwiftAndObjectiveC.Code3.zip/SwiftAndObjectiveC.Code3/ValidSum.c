
#include <stdio.h>
#include <limits.h>


// Theorem -: int Type

// Proof of Type int
int sum( int x, int y ) {
	int result = 0;
	if ( y > 0 && x > INT_MAX - y ) ||
	   ( y < 0 && x < INT_MIN - y ) {
	   	printf("Cann't Calcualate Sum These Values");
	   	//return result;
	}  else {
		//Confirms To int Type
		return result = x + y;
	}

	return result;
}

int main() {

}