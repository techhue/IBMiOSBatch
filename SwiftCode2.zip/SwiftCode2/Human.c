#include <stdio.h>

typedef struct human_type {
	int id;
	char name[100]; 
	void (*dance)();
	void (*sing)();
} Human;

void classicalBhangra() {
	printf("\nOyeee Hoyeeee.... Balleeeee Balleeee\n");
}

void classicalSinging() {
	printf("\nOOOoooo Hooo,...\n");
}

int main() {
	Human h = { 10, "Ram Singh", classicalBhangra, classicalSinging };

	printf("\n Human ID: %d, Human Name: %s", h.id, h.name );
	h.dance();
	h.sing();
}

