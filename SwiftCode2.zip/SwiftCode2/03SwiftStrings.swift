let someString = "\"Some String Value\""
print(someString)

let bigString = """

Vikram Batraa Zindabaad!!!
Something More...
Ye Dil Maangeee More....
"""
print(bigString)

let bigStringAgain = "\nVikram Batraa Zindabaad!!!\nSomething More...\nYe Dil Maangeee More...."
print(bigStringAgain)

let softWrappedString = """

Vikram Batraa Zindabaad!!! \
Vikram Amar Rahain!... \
Vikram Zindabaad!!!
Something More...
Ye Dil Maangeee More....
"""
print(softWrappedString)


let bigStringMore = """

	Vikram Batraa Zindabaad!!!
			Something More...
	Ye Dil Maangeee More....

"""
print(bigStringMore)

let bigStringOnceMore = """

	"Vikram Batraa Zindabaad!!!"
			Something More...
	Ye Dil Maangeee More....

"""
print(bigStringOnceMore)


let someString1 = "Some \"String\" Value"
print(someString1)

// Feature Added In Swift 5.0.1+
// # will ignore meaning of Escape Sequences
// let someString2 = #"Some \"String\" Value"#
// print(someString2)

// let someString3 = #"Some "String" Value"#
// print(someString3)

var oneString = "Rohit Sharma"
let oneMoreString = String()

if oneString.isEmpty {
	print("Emptiness Found")
} else {
	print("String is Awesome!")
}

if oneMoreString.isEmpty {
	print("Emptiness Found")
} else {
	print("String is Awesome!")
}

oneString = oneString + oneMoreString
var onceMoreString = "Hello Rockstar!"

onceMoreString = onceMoreString + oneString
print(onceMoreString)

for c in oneString {
	print(c)
}

//oneString[0] = "M"
oneString = "Mohit Sharma"
print(oneString)

//let excalamationMark = "!"  			// excalamationMark is String Type
let excalamationMark: Character = "!"	// Explicitly Mentioning Character Type

print(excalamationMark)
oneString = oneString + String(excalamationMark)
print(oneString)

//_________________________________________________________

let catCharacters: [Character] = ["C", "a", "t", "🐱"]
let catString = String(catCharacters)
print(catString)

// An arbitrary Unicode scalar value, written as \u{n}, 
// where n is a 1–8 digit hexadecimal number (Unicode Point)
let catCharacters1: [Character] = ["C", "a", "t", "\u{1F408}", "\u{1F431}" ]
let catString1 = String(catCharacters1)
print(catString1)

let dollarSign = "\u{24}"
print(dollarSign)

let blackHeart = "\u{2665}"
print(blackHeart)

let sparklingHeart = "\u{1F496}"
print(sparklingHeart)

for c in catString1 {
	print(c)
}

let string1 = "Hello " 
let string2 = "World!"

var welcome = string1 + string2
print(welcome)

welcome += " World is Awesome!"
print(welcome)

welcome.append(" and as well as horible...")
print(welcome)


let badStart = """
one
two
"""

let end = """
three
"""

print(badStart + end)

let goodStart = """
one
two

"""
print(goodStart + end)


let mutliplier = 3

// String Interpolation - Values In \(Expr) get Substituted 
// \(Expr) here Expr is evaluated and result is Substituted

let message = "\(mutliplier) times 20 is \(mutliplier * 20)"
print(message)


//______________________________________________________________
// Supported SWIFT 5.0 Onwards
//______________________________________________________________

// print(#""Life is Awesome", By SomeAnanda!"#)
// print(#""6 times 7 is \(6 * 7)""#)
// print(#""6 times 7 is \#(6 * 7)""#)


//______________________________________________________________
// UNICODES IN SWIFT
//______________________________________________________________

print("\u{0061}")
print("\u{1F618}")

let eAcute: Character = "\u{E9}"
print(eAcute)

let eAcuteSplit1: Character = "\u{65}"
let eAcuteSplit2: Character = "\u{301}"
print(eAcuteSplit1)
print(eAcuteSplit2)

// let eAcuteAdded = eAcuteSplit1 + eAcuteSplit2
// let eAcuteAdded: Character = "\u{65}" + "\u{301}"
// print(eAcuteAdded)

let eAcuteCombined: Character = "\u{65}\u{301}"
print(eAcuteCombined)

if eAcute == eAcuteCombined {
	print("Both Are Same")
} else {
	print("Both Are Not Same")
}

// Hangul syllables from the Korean alphabet can be represented 
// as either a precomposed or decomposed sequence
let precomposed: Character = "\u{D55C}"                  // 한
let decomposed: Character = "\u{1112}\u{1161}\u{11AB}"   // ᄒ, ᅡ, ᆫ

if precomposed == decomposed {
	print("Both Are Same")
} else {
	print("Both Are Not Same")
}

let unusualMenagerie = "Koala 🐨, Snail 🐌, Penguin 🐧, Dromedary 🐪"
print("unusualMenagerie has \(unusualMenagerie.count) characters")

let koala = "Koala 🐨"
print("koala has \(koala.count) characters")

var word = "cafe"
print(word, word.count)

word += "\u{301}"
print(word, word.count)


//Swift 5.0+ Onwards...
let greeting = "Guten Tag!"
var value1 = greeting[greeting.startIndex] 
print(value1)

var value3 = greeting[ greeting.index(after: greeting.startIndex) ]
print(value3)

var value2 = greeting[ greeting.index(before: greeting.endIndex) ]
print(value2)


let index = greeting.index(greeting.startIndex, offsetBy: 7)
print(greeting[index])

// print( greeting[greeting.endIndex] )
// print( greeting.index(after: greeting.endIndex) )

for index in greeting.indices {
	print("At \(index) Value Is: \(greeting[index])")
	// print("Value Is: \(greeting[index])")
}

print()
for c in greeting {
	print("Value Is:", c)
}

// print(greeting.indices)

var moreWelcome = "Hello"
print(moreWelcome)

// print( moreWelcome.index(after: moreWelcome.endIndex) )
// print( moreWelcome.index(at: moreWelcome.endIndex) )

moreWelcome.insert("?", at: moreWelcome.endIndex )
print(moreWelcome)

let insertIndex = moreWelcome.endIndex
// moreWelcome.insert(contentsOf: " World!", at: moreWelcome.index(before: insertIndex))
moreWelcome.insert(contentsOf: " World!", at: moreWelcome.endIndex)
print(moreWelcome)

moreWelcome.remove(at: moreWelcome.index(before: moreWelcome.endIndex))
print(moreWelcome)


let quote = "We're a a lot alike, you and I."
let sameQuote = "We're a a lot alike, you and I."

if quote == sameQuote {
	print("Equal String...")
} else {
	print("UnEqual String...")
}

let moreQuote = String("We're a a lot alike, you and I.")

if quote == moreQuote {
	print("Equal String...")
} else {
	print("UnEqual String...")
}

let eAcuteQuestion = "Voulez-vous un caf\u{E9}?"
let combinedEAcuteQuestion1 = "Voulez-vous un caf\u{65}\u{301}?"
let combinedEAcuteQuestion2 = "Voulez-vous un cafe\u{301}?"

print(eAcuteQuestion)
print(combinedEAcuteQuestion1)

if eAcuteQuestion == combinedEAcuteQuestion1 {
	print("Equal String...")
} else {
	print("UnEqual String...")
}

print(eAcuteQuestion)
print(combinedEAcuteQuestion2)
if eAcuteQuestion == combinedEAcuteQuestion2 {
	print("Equal String...")
} else {
	print("UnEqual String...")
}

print(combinedEAcuteQuestion1)
print(combinedEAcuteQuestion2)
if combinedEAcuteQuestion1 == combinedEAcuteQuestion2 {
	print("Equal String...")
} else {
	print("UnEqual String...")
}

let latinCapitalLetterA: Character = "\u{41}"
let cyrillicCapitalLetterA: Character = "\u{0410}"
print(latinCapitalLetterA)
print(cyrillicCapitalLetterA)

if latinCapitalLetterA == cyrillicCapitalLetterA {
	print("Equal String...")
} else {
	print("UnEqual String...")
}

let movieDialogues: [String] = [
	"Act 1: Kitne Aaadmi Thee...",
	"Act 1: Mind block!",
	"Act 2: Once I Fix! That's It!",
	"Act 2: Ae Basanti En Kuto Ke Saamne Maat Nachnaaa...",
	"Act 1: All Is Well",
	"Act 2: Virus Verus Sastra Boodhi",
	"Act 1: Shorterm Memory Loss",
	"Act 1: Tareek pe Tareek"
]

var act1DialogueCount = 0
var act2DialogueCount = 0

print()
for dialogue in movieDialogues {
	if dialogue.hasPrefix("Act 1:") {
		act1DialogueCount += 1
	} else if dialogue.hasPrefix("Act 2:") {
		act2DialogueCount += 1
	}

	if dialogue.hasSuffix("...") {
		print(dialogue)	
	}
}

print("Act 1 Dialogue Count: ", act1DialogueCount)
print("Act 2 Dialogue Count: ", act2DialogueCount)

print()
print(catString1)

for c in catString1 {
	print(c, terminator: "   ")
}

print()
for c in catString1.utf8 {
	print(c, terminator: "   ")
}

let catArray = Array(catString1)

let dogString = "Dog!!\u{1F436}"

print("\n")
print(dogString)
for c in dogString.utf8 {
	print(c, terminator: "   ")
}
print()
for c in dogString.utf16 {
	print(c, terminator: "   ")
}
print()
for c in dogString.unicodeScalars {
	print(c, terminator: "   ")
}

// When a Unicode string is written to a text file or some other storage, the Unicode scalars in that string are encoded in one of several Unicode-defined encoding forms. Each form encodes the string in small chunks known as code units. These include the UTF-8 encoding form (which encodes a string as 8-bit code units), the UTF-16 encoding form (which encodes a string as 16-bit code units), and the UTF-32 encoding form (which encodes a string as 32-bit code units).

// Can Access a String value in one of three other Unicode-compliant representations:

// A collection of UTF-8 code units (accessed with the string’s utf8 property)
// A collection of UTF-16 code units (accessed with the string’s utf16 property)
// A collection of 21-bit Unicode scalar values, equivalent to the string’s 
//	UTF-32 encoding form (accessed with the string’s unicodeScalars property)


