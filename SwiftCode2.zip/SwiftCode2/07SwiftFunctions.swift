
func hello() {
	print("Ding Dong...")
}
hello()

func sayHelloWorld() -> String {
	return "Hello World!"
}
print(sayHelloWorld())

func sayHello( personName: String ) -> String {
	let greeting = "Hello " + personName + "!"
	return greeting
}
print( sayHello( personName: "Katrina Kaif"))
// print( sayHello( "Katrina Kaif"))

func openRangeLength(start: Int, end: Int) -> Int {
	return end - start
}
print( openRangeLength(start: 1, end: 10))

func printAndCount(stringToPrint: String ) -> Int {
	print(stringToPrint)
	return stringToPrint.count
}
print( printAndCount(stringToPrint: "Ting Tong King Kong") )

func minimumMaximum( numbers: [Int] ) -> (min: Int, max: Int) {
	var currentMin = numbers[0]
	var currentMax = numbers[0]

	for number in numbers {
		if number > currentMax {
			currentMax = number
		} else if number < currentMin {
			currentMin = number
		}
	}
	return (currentMin, currentMax)
}

let bounds = minimumMaximum( numbers : [10, 20, -90, 100, 800, -10, 3, 4, 5, 9])
print(bounds)
print("Minimum Value: \(bounds.0) \nMaximum Value: \(bounds.1)")
print("Minimum Value: \(bounds.min) \nMaximum Value: \(bounds.max)")


// Hathi Ke Danth: Khaane Ke Aur and Deekhaanee Ke Aur
// Elephant's Teeths: To Show Off and To Eat

// External Parameters
// Internal Parameters

func join(firstString s1: String, secondString s2: String, 
	joinWith joiner: String) -> String {
    return s1 + joiner + s2
}

//var resultString = join(s1: "hello", s2: "world", joiner: ", ") 
var resultString = join(firstString: "hello", secondString: "world", joinWith: ", ") 
print(resultString)

// Other Non Standard Following Code or 3rd Party Library
func joinOther(s1: String, s2: String, joiner: String) -> String {
    return s1 + joiner + s2
}

// Our Own APIs w.r.t. Project Guidelines
func joinStrings(firstString s1: String, secondString s2: String, 
	joinWith joiner: String) -> String {
    return joinOther(s1: s1, s2: s2, joiner: joiner)
}
resultString = joinStrings(firstString: "hello", secondString: "world", joinWith: ", ") 
print(resultString)

func containCharacter(string: String, searchCharacter: Character ) -> Bool {
	for character in string {
		if character == searchCharacter {  
			return true
		}
	}
	return false
}
let containResult = containCharacter(string: "Wonderful One!", searchCharacter: "O")
print(containResult)

// Varidiac Argument Mechanism -> Polymorphism
func arithmeticMean(base: Double = 0.0, numbers: Double...) -> Double {
	var total = base
	for number in numbers {
		total = total + number
	}
	return total / Double(numbers.count)
}

var resultMean = arithmeticMean(base: 100, numbers: 1, 2, 3, 4, 5, 6, 7, 8, 9, 10)
print(resultMean)
resultMean = arithmeticMean(numbers: 1, 2, 3, 4, 5, 6)
print(resultMean)
resultMean = arithmeticMean(numbers: 1, 2, 3, 4)
print(resultMean)
let someNumbers: [Double] = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

//var resultMean = arithmeticMean(base: 100, numbers: someNumbers)


func sum(x: Int, y: Int) -> Int { return x + y }
func sub(x: Int, y: Int) -> Int { return x - y }
func mul(x: Int, y: Int) -> Int { return x * y }

func calculator(x: Int, y: Int, operation: (Int, Int) -> Int ) -> Int { 
	return operation(x, y)
}

let a = 20
let b = 30
var result = calculator(x: a, y: b, operation: sum)
print(result)

result = calculator(x: a, y: b, operation: sub)
print(result)

let something: (Int, Int, (Int, Int)-> Int) -> Int = calculator
result = something(a, b, mul)
print(result)

let something1: (_ x: Int, _ y: Int, _ operation: (Int, Int)-> Int) -> Int = calculator
result = something1(a, b, mul)
print(result)


func stepForward(input: Int) -> Int {
    return input + 1
}
func stepBackward(input: Int) -> Int {
    return input - 1
}

func chooseStepFunction(backwards: Bool) -> (Int) -> Int {
    return backwards ? stepBackward : stepForward
}

var currentValue = 3
let moveNearerToZero = chooseStepFunction(backwards: currentValue > 0)

print(currentValue)
currentValue = moveNearerToZero(currentValue)
print(currentValue)
currentValue = moveNearerToZero(currentValue)
print(currentValue)
currentValue = moveNearerToZero(currentValue)
print(currentValue)








