//
//  SettingsViewController.swift
//  Messenger
//
//  Created by XCode on 7/26/16.
//  Copyright © 2016 techhue. All rights reserved.
//

import UIKit

class SettingsViewController: UITableViewController
{
    let settingOptions:[String] = ["User Name", "Password", "Refresh Interval"]
    let preferences = UserDefaults.standard
    
    static let USER_NAME_KEY = "User Name"
    static let PASSWORD_KEY = "Password"
    static let REFRESH_INTERVAL_KEY = "Refresh Interval"

    override func viewDidLoad()
    {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
    }

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int
    {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        // #warning Incomplete implementation, return the number of rows
        return self.settingOptions.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "settingsCell", for: indexPath)

        cell.textLabel?.text = self.settingOptions[indexPath.row]

        return cell
    }
    
    var tField: UITextField!
    
    func configurationTextField(_ textField: UITextField!)
    {
        textField.placeholder = "Enter the prefered value"
        tField = textField
    }
    
    func handleCancel(_ alertView: UIAlertAction!)
    {
        print("Cancelled !!")
    }
    
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        var message: String = String()
        
        if indexPath.row == 0
        {
            message = "Enter User Name"
        }
        else if indexPath.row == 1
        {
            message = "Enter Password"
        }
        else
        {
            message = "Enter Refresh Interval"
        }
        
        let alert = UIAlertController(title: message, message: "", preferredStyle: .alert)
        
        alert.addTextField(configurationHandler: configurationTextField)
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler:handleCancel))
        if indexPath.row == 0
        {
            alert.addAction(UIAlertAction(title: "Done", style: .default, handler:{ (UIAlertAction) in
                self.savePreference(self.tField.text!, key: SettingsViewController.USER_NAME_KEY)
            }))
        }
        else if indexPath.row == 1
        {
            alert.addAction(UIAlertAction(title: "Done", style: .default, handler:{ (UIAlertAction) in
                self.savePreference(self.tField.text!, key: SettingsViewController.PASSWORD_KEY)
            }))
        }
        else
        {
            alert.addAction(UIAlertAction(title: "Done", style: .default, handler:{ (UIAlertAction) in
                self.savePreference(self.tField.text!, key: SettingsViewController.REFRESH_INTERVAL_KEY)
            }))
        }
        
        self.present(alert, animated: true, completion:
        {
            print("completion block")
        })
    }
    
    func savePreference(_ value: String, key: String)
    {
        self.preferences.setValue(value, forKey: key)
        let didSave = self.preferences.synchronize()
        if !didSave
        {
            print("Error while saving prefrence")
        }
    }
}
