//
//  RefreshService.swift
//  Messenger
//
//  Created by XCode on 7/26/16.
//  Copyright © 2016 techhue. All rights reserved.
//

import UIKit

class RefreshService: Service
{
    override func doInBackground()
    {
        print("Background time remaining = \(UIApplication.shared.backgroundTimeRemaining)")
        let statusMessages = MessengerClient.sharedMessengerClient.getTimeline(30)
        print(statusMessages)
    }
}
