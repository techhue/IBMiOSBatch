//
//  Status.swift
//  Messenger
//
//  Created by XCode on 7/26/16.
//  Copyright © 2016 techhue. All rights reserved.
//

import UIKit

class Status: NSObject
{
    var statusID: Double?
    var createdAt: Date?
    var userName: String?
    var message: String?
    
    override init()
    {
        super.init()
    }
    
    convenience init(statusID:Double, createdDate createdAt: Date, createdUserName userName: String, userMessage message:String)
    {
        self.init()
        self.statusID = statusID
        self.createdAt = createdAt
        self.userName = userName
        self.message = message
    }
}
