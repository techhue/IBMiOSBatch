//
//  Service.swift
//  Messenger
//
//  Created by XCode on 7/26/16.
//  Copyright © 2016 techhue. All rights reserved.
//

import UIKit

class Service: NSObject
{
    var backgroundTask: UIBackgroundTaskIdentifier?
    var frequency: Int = 30
    var updateTimer: Timer?
    
    override init()
    {
        super.init()
        print("Service Init")
    }
    
    convenience init(frequency: Int)
    {
        self.init()
        self.frequency = frequency
    }
    
    func startService()
    {
        self.startBackgroundTask()
    }
    
    func doInBackground()
    {
        // Override this method to do whatever you want
    }
    
    func stopService()
    {
        self.updateTimer?.invalidate()
        self.updateTimer = nil
        UIApplication.shared.endBackgroundTask(self.backgroundTask!)
        self.backgroundTask = UIBackgroundTaskInvalid
    }
    
    fileprivate func startBackgroundTask()
    {
        self.updateTimer = Timer.scheduledTimer(timeInterval: TimeInterval.init(self.frequency), target: self, selector: #selector(Service.doInBackground), userInfo: nil, repeats: true)
        self.backgroundTask = UIApplication.shared.beginBackgroundTask(expirationHandler: {
            self.endBackgroundTask()
        })
    }
    
    fileprivate func endBackgroundTask()
    {
        self.updateTimer?.invalidate()
        self.updateTimer = nil
        UIApplication.shared.endBackgroundTask(self.backgroundTask!)
        self.backgroundTask = UIBackgroundTaskInvalid
        self.startBackgroundTask()
    }

}
