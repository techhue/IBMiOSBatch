//
//  RefreshService.swift
//  Messenger
//
//  Created by XCode on 7/26/16.
//  Copyright © 2016 techhue. All rights reserved.
//

import UIKit
import CoreData

class RefreshService: Service
{
    override func doInBackground()
    {
        print("Background time remaining = \(UIApplication.shared.backgroundTimeRemaining)")
        let statusMessages = MessengerClient.sharedMessengerClient.getTimeline(30)
        statusMessages.enumerateObjects({
            object, index, stop in
            let status = object as! Status
            let predicate = NSPredicate(format: "userID = %@", NSNumber(value: status.statusID! as Double))
            let fetchRequest = NSFetchRequest<NSFetchRequestResult>()
            fetchRequest.entity = NSEntityDescription.entity(forEntityName: "Timeline", in: DatabaseManager.sharedDatabaseManager.managedObjectContext)
            fetchRequest.predicate = predicate

            do
            {
                
                if (try  DatabaseManager.sharedDatabaseManager.managedObjectContext.fetch(fetchRequest).count == 0)
                {
                    let entity = NSEntityDescription.entity(forEntityName: "Timeline", in: DatabaseManager.sharedDatabaseManager.managedObjectContext)
                    let item = NSManagedObject(entity: entity!, insertInto: DatabaseManager.sharedDatabaseManager.managedObjectContext)
                    
                    
                    item.setValue(NSNumber(value: status.statusID! as Double), forKey: "userID")
                    item.setValue(status.userName!, forKey: "user")
                    item.setValue(status.message!, forKey: "message")
                    item.setValue(status.createdAt!, forKey: "createdAt")
                    do
                    {
                        try item.managedObjectContext?.save()
                    }
                    catch
                    {
                        let error = error as NSError
                        print("\(error), \(error.userInfo)")
                    }
                }
                else
                {
                    print("Timeline Status is already exist")
                }
            }
            catch
            {
                let error = error as NSError
                print("\(error), \(error.userInfo)")
            }
        })
        
        print("Service running at = \(self.getCurrentNetworkTime())")
    }
    
    func getCurrentNetworkTime() -> Double
    {
        return Date().timeIntervalSince1970
    }
}
