//
//  Timeline.swift
//  Messenger
//
//  Created by XCode on 7/26/16.
//  Copyright © 2016 techhue. All rights reserved.
//

import Foundation
import CoreData


class Timeline: NSManagedObject {

// Insert code here to add functionality to your managed object subclass

}
