from django.shortcuts import render
from django.http import HttpResponse, HttpResponseRedirect
from django.template import RequestContext, loader
from django.http import Http404
import datetime
from django.utils import timezone
import json

from Status.models import Login, PublicTimeline

def index(request):
	timelineStatus = PublicTimeline.objects.order_by('-time')[:20]
	template = loader.get_template('status/index.html')
	context = RequestContext(request, {
		'timelineStatus': timelineStatus,
	})
	return HttpResponse(template.render(context))

def postStatus(request):
	status = ''
	if request.POST:
		status = request.POST.get('status')
		if status != '':
			print request
			timelineStatus = PublicTimeline(studentName = "student", status = status, time = timezone.now())
			timelineStatus.save()
		return HttpResponseRedirect('/status/')
	else:
		return HttpResponseRedirect('/status/')

def postStatus1(request):
	if request.POST:
		data = json.loads(request.body)
		statusData = data.get('Status', None)
		userName = data.get('Username', None)
		password = data.get('Password', None)
		if userName == "student" and password == "password":
			if statusData != '':
				timelineStatus = PublicTimeline(studentName = "student", status = statusData, time = timezone.now())
				timelineStatus.save()
				return HttpResponse(status = 200)
			else:
				return HttpResponse(status = 204)
		else:
			return HttpResponse(status = 401)

def getTimeline(request):
	timelineStatus = PublicTimeline.objects.order_by('-time')[:20]
	timelineStatusReponses = []
	for status in timelineStatus:
		timelineStatusReponse = {
		"id" : status.id,
		"studentName" : status.studentName,
		"status" : status.status,
		"time" : str(status.time)
		}
		timelineStatusReponses.append(timelineStatusReponse)
	return HttpResponse(json.dumps(timelineStatusReponses), content_type = "application/json", status = 200)

	
