from django.db import models

# Create your models here.

class Login(models.Model):
	studentName = models.CharField(max_length = 200)
	studentPassword = models.CharField(max_length = 10)

class PublicTimeline(models.Model):
	studentName = models.CharField(max_length = 200)
	status = models.CharField(max_length = 500)
	time = models.DateTimeField('date published')
