from django.contrib import admin

# Register your models here.
from Status.models import Login, PublicTimeline

admin.site.register(Login)
admin.site.register(PublicTimeline)
